import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
data = pd.read_csv('Telco-Customer-Churn.csv')
print(data.head())
## Data Processing
print(data.isnull().any())
print (data.describe(()))
print(data.dtypes)
Fact = preprocessing.LabelEncoder()
# Factorise the string values into numbers.
data['gender']=Fact.fit_transform(data['gender'])
data['Partner']=Fact.fit_transform(data['Partner'])
data['Dependents']=Fact.fit_transform(data['Dependents'])
data['PhoneService']=Fact.fit_transform(data['PhoneService'])
data['MultipleLines']=Fact.fit_transform(data['MultipleLines'])
data['InternetService']=Fact.fit_transform(data['InternetService'])
data['OnlineSecurity']=Fact.fit_transform(data['OnlineSecurity'])
data['OnlineBackup']=Fact.fit_transform(data['OnlineBackup'])
data['DeviceProtection']=Fact.fit_transform(data['DeviceProtection'])
data['TechSupport']=Fact.fit_transform(data['TechSupport'])
data['StreamingTV']=Fact.fit_transform(data['StreamingTV'])
data['StreamingMovies']=Fact.fit_transform(data['StreamingMovies'])
data['Contract']=Fact.fit_transform(data['Contract'])
data['PaperlessBilling']=Fact.fit_transform(data['PaperlessBilling'])
data['PaymentMethod']=Fact.fit_transform(data['PaymentMethod'])
data['TotalCharges']=Fact.fit_transform(data['TotalCharges'])
print(data.head())
##Features Selection , plot the correlation of all features column with target variable 'Churn'
X = data[['SeniorCitizen', 'Partner', 'Dependents' ,  'tenure',   'PhoneService', 'InternetService' ,
          'OnlineSecurity' ,  'OnlineBackup', 'DeviceProtection', 'TechSupport',
         'Contract', 'PaperlessBilling', 'PaymentMethod', 'MonthlyCharges']] #independent columns
y = data['Churn']    #target column i.e price range
from sklearn.ensemble import ExtraTreesRegressor
import matplotlib.pyplot as plt
#get correlations of each features in dataset
corrmat = data.corr()
print(corrmat)
corrmat.to_csv('Telco_Customer_Churn_corr.csv')
top_corr_features = corrmat.index
plt.figure(figsize=(16,16))
g=sns.heatmap(data[top_corr_features].corr(),annot=True,cmap="RdYlGn")
plt.show()
####as per heatmap correlation ; only tenure,MonthlyCharges,StreamingMovies,StreamingTV influencing the churn

X1 = data[['tenure','StreamingMovies','StreamingTV','MonthlyCharges']] #independent columns
y1 = data['Churn']    #target column i.e price range
##Split data set to train and test
X_train, X_test, y_train, y_test = train_test_split(X1, y1, test_size = 0.30, random_state = 0)
## Import the random Forest classifier model and fit
from sklearn.ensemble import RandomForestClassifier
rf_classifier = RandomForestClassifier(n_estimators=100, max_depth=2,random_state = 0)
rf_classifier.fit(X_train, y_train)
##Predict the Customer Churn
y_pred = rf_classifier.predict(X_test)
##Accuracy
from sklearn import metrics
print("Model Accuracy:", metrics.accuracy_score(y_test, y_pred))
from sklearn.model_selection import cross_val_score
from sklearn.metrics import classification_report, confusion_matrix
rf_classification_cv_score = cross_val_score(rf_classifier, X1, y1, cv=10, scoring='roc_auc')
print("=== Confusion Matrix ===")
print(confusion_matrix(y_test, y_pred))
print('\n')
print("=== Classification Report ===")
print(classification_report(y_test, y_pred))
print('\n')
print("=== All AUC Scores ===")
print(rf_classification_cv_score)
print('\n')
print("=== Mean AUC Score ===")
print("Mean AUC Score - Random Forest: ", rf_classification_cv_score.mean())




