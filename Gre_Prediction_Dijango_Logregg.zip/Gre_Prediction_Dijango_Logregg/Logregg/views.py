# importing required packages
from django.http import HttpResponse
from django.template import loader
from django.views.decorators.csrf import csrf_exempt
# import warnings filter
from warnings import simplefilter
# ignore all future warnings
simplefilter(action='ignore', category=FutureWarning)
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import metrics
import matplotlib.pyplot as plt
# disabling csrf (cross site request forgery)
@csrf_exempt
def index(request):
    # if post request came
    if request.method == 'POST':
        # getting values from post
        gmat = request.POST.get('gmat')
        gpa = request.POST.get('gpa')
        work_experience = request.POST.get('exp')
        df = pd.read_csv('gre.csv')
        X = df[['gmat', 'gpa', 'work_experience']]
        y = df['admitted']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)
        from sklearn.linear_model import LogisticRegression
        lr = LogisticRegression()
        lr.fit(X_train, y_train)
        y_pred = lr.predict(X_test)
        new_candidates = {'gmat': [590],
                          'gpa': [2],
                          'work_experience': [3]
                          }
        new_candidates['gmat'][0] = int(gmat)
        new_candidates['gpa'][0] = float(gpa)
        new_candidates['work_experience'][0] = int(work_experience)
        df2 = pd.DataFrame(new_candidates, columns=['gmat', 'gpa', 'work_experience'])
        y_pred = lr.predict(df2)
        name=str(y_pred[0])

        # adding the values in a context variable
        context = {
            'name': name,
                    }

        # getting our showdata template
        template = loader.get_template('showdata.html')

        # returing the template
        return HttpResponse(template.render(context, request))
    else:
        # if post request is not true
        # returing the form template
        template = loader.get_template('index.html')
        return HttpResponse(template.render())