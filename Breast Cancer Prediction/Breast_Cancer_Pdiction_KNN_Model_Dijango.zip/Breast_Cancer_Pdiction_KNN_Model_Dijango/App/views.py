# importing required packages
from django.http import HttpResponse
from django.template import loader
from django.views.decorators.csrf import csrf_exempt
# import warnings filter
from warnings import simplefilter
# ignore all future warnings
simplefilter(action='ignore', category=FutureWarning)
import pandas as pd
import numpy as np
from sklearn.datasets import load_breast_cancer
##from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
import seaborn as sns
import matplotlib.pyplot as plt
##from sklearn import metrics
##import matplotlib.pyplot as plt
# disabling csrf (cross site request forgery)
@csrf_exempt
def index(request):
    # if post request came
    if request.method == 'POST':
        # getting values from post
        mean_area = request.POST.get('mean area')
        mean_perimeter = request.POST.get('mean perimeter')
        breast_cancer = load_breast_cancer()
        X = pd.DataFrame(breast_cancer.data, columns=breast_cancer.feature_names)
        X = X[['mean area', 'mean perimeter']]
        ##print(X)
        y = pd.Categorical.from_codes(breast_cancer.target, breast_cancer.target_names)
        ##print(y)
        y = pd.get_dummies(y, drop_first=True)
        ##print(y)
        X_train, X_test, y_train, y_test = train_test_split(X, y,random_state=1)
        knn = KNeighborsClassifier(n_neighbors=5, metric='euclidean')
        knn.fit(X_train, np.ravel(y_train))
        y_pred = knn.predict(X_test)
        data = load_breast_cancer()
        data1 = pd.DataFrame(data.data, columns=data.feature_names)
        print(data1.head())
        print(data1.columns)
        data1.columns = data.feature_names
        NUM_POINTS = 7
        features_mean = list(data1.columns[1:NUM_POINTS + 1])
        feature_names = data.feature_names[1:NUM_POINTS + 1]
        color_dic = {0: 'red', 1: 'blue'}
        target_list = list(data['target'])
        colors = list(map(lambda x: color_dic.get(x), target_list))
        sns_fig= pd.plotting.scatter_matrix(data1[features_mean], c=colors, alpha=0.4, figsize=((8, 8)))
        plt.savefig('C:/Users/RAVI/PycharmProjects/Breast_Cancer_Pdiction_KNN_Model_Dijango/App/static/my_app/Scatter_Plot2.jpg')
        plt.close()
        sns.scatterplot(
            x='mean area',
            y='mean perimeter',
            hue='benign',
            data=X_test.join(y_test, how='outer')
        )
        plt.savefig('C:/Users/RAVI/PycharmProjects/Breast_Cancer_Pdiction_KNN_Model_Dijango/App/static/my_app/Scatter_Plot.jpg')
        plt.scatter(
            X_test['mean area'],
            X_test['mean perimeter'],
            c=y_pred,
            cmap='coolwarm',
            alpha=0.7
        )
        plt.xlabel('mean area')
        plt.ylabel('mean perimeter')
        plt.savefig('C:/Users/RAVI/PycharmProjects/Breast_Cancer_Pdiction_KNN_Model_Dijango/App/static/my_app/Scatter_Plot1.jpg')

        new_candidates = {'mean area': [1001],
                          'mean perimeter': [122]
                          }
        new_candidates['mean area'][0] = int(mean_area)
        new_candidates['mean perimeter'][0] = float(mean_perimeter)
        df2 = pd.DataFrame(new_candidates, columns=['mean area', 'mean perimeter'])
        y_pred = knn.predict(df2)
        if (y_pred == [1]):
            name = 'Cancer'
        else:
            name = 'No Cancer'

        print(name)


        # adding the values in a context variable
        context = {
            'name': name,
                    }

        # getting our showdata template
        template = loader.get_template('showdata.html')

        # returing the template
        return HttpResponse(template.render(context, request))
    else:
        # if post request is not true
        # returing the form template
        template = loader.get_template('index.html')
        return HttpResponse(template.render())