import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn import metrics
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory
import os
credit_data = pd.read_csv('cs-training.csv')
test_data = pd.read_csv('cs-test.csv')
##credit_data.columns
#drop lines with missing data (NA)
credit_data.dropna(axis=1)
cols_with_missing = [col for col in credit_data.columns
                         if credit_data[col].isnull().any()]
reduced_original_data = credit_data.drop(cols_with_missing, axis=1)
reduced_test_data = test_data.drop(cols_with_missing,axis=1)
reduced_original_data.columns
#specify the target variable
y = reduced_original_data.SeriousDlqin2yrs
#create list of features
feature_names = ['RevolvingUtilizationOfUnsecuredLines', 'age',
       'NumberOfTime30-59DaysPastDueNotWorse', 'DebtRatio',
       'NumberOfOpenCreditLinesAndLoans', 'NumberOfTimes90DaysLate',
       'NumberRealEstateLoansOrLines', 'NumberOfTime60-89DaysPastDueNotWorse']
#create data corresponding to the features
X = reduced_original_data[feature_names]
#review data
print(X.describe)
print(X.head)
from sklearn.tree import DecisionTreeRegressor
#specify the model, set any numeric valye as parameter to ensure reproducibility 
credit_model = DecisionTreeRegressor(random_state=1)

#fit the model
credit_model.fit(X,y)
#make predictions
predictions = credit_model.predict(X)
print(predictions)




