import pandas as pd
import numpy as np
import seaborn as sns
data = pd.read_csv("movie_metadata.csv")
##data=d.fillna('')
data.num_critic_for_reviews=data.num_critic_for_reviews.fillna(data.num_critic_for_reviews.mean())

data.duration=data.duration.fillna(data.duration.mean())

data.director_facebook_likes=data.director_facebook_likes.fillna(data.director_facebook_likes.mean())

data.actor_3_facebook_likes=data.actor_3_facebook_likes.fillna(data.actor_3_facebook_likes.mean())

data.actor_1_facebook_likes=data.actor_1_facebook_likes.fillna(data.actor_1_facebook_likes.mean())

data.actor_2_facebook_likes=data.actor_2_facebook_likes.fillna(data.actor_2_facebook_likes.mean())

data.gross=data.gross.fillna(data.gross.mean())

data.num_voted_users=data.num_voted_users.fillna(data.num_voted_users.mean())

data.num_user_for_reviews=data.num_user_for_reviews.fillna(data.num_user_for_reviews.mean())

data.budget=data.budget.fillna(data.budget.mean())

X = data[['num_critic_for_reviews','duration','director_facebook_likes','actor_3_facebook_likes','actor_1_facebook_likes','actor_2_facebook_likes','gross','num_voted_users','budget','movie_facebook_likes','cast_total_facebook_likes']]  #independent columns
y = data['imdb_score']    #target column i.e price range
from sklearn.ensemble import ExtraTreesRegressor
import matplotlib.pyplot as plt
#get correlations of each features in dataset
corrmat = data.corr()
print(corrmat)
corrmat.to_csv('movies_corr.csv')
top_corr_features = corrmat.index
plt.figure(figsize=(16,16))

g=sns.heatmap(data[top_corr_features].corr(),annot=True,cmap="RdYlGn")
plt.show()


