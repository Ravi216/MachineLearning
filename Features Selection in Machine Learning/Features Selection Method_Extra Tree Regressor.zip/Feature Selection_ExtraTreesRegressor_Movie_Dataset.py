import pandas as pd
import numpy as np
data = pd.read_csv("movie_metadata.csv")
##data=d.fillna('')
data.num_critic_for_reviews=data.num_critic_for_reviews.fillna(data.num_critic_for_reviews.mean())

data.duration=data.duration.fillna(data.duration.mean())

data.director_facebook_likes=data.director_facebook_likes.fillna(data.director_facebook_likes.mean())

data.actor_3_facebook_likes=data.actor_3_facebook_likes.fillna(data.actor_3_facebook_likes.mean())

data.actor_1_facebook_likes=data.actor_1_facebook_likes.fillna(data.actor_1_facebook_likes.mean())

data.actor_2_facebook_likes=data.actor_2_facebook_likes.fillna(data.actor_2_facebook_likes.mean())

data.gross=data.gross.fillna(data.gross.mean())

data.num_voted_users=data.num_voted_users.fillna(data.num_voted_users.mean())

data.num_user_for_reviews=data.num_user_for_reviews.fillna(data.num_user_for_reviews.mean())

data.budget=data.budget.fillna(data.budget.mean())

X = data[['num_critic_for_reviews','duration','director_facebook_likes','actor_3_facebook_likes','actor_1_facebook_likes','actor_2_facebook_likes','gross','num_voted_users','budget','movie_facebook_likes','cast_total_facebook_likes']]  #independent columns
y = data['imdb_score']    #target column i.e price range
from sklearn.ensemble import ExtraTreesRegressor
import matplotlib.pyplot as plt
model = ExtraTreesRegressor()
model.fit(X,y)
print(model.feature_importances_) #use inbuilt class feature_importances of tree based classifiers
#plot graph of feature importances for better visualization
feat_importances = pd.Series(model.feature_importances_, index=X.columns)
feat_importances.nlargest(100).plot(kind='barh')
plt.show()

