import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.datasets import load_breast_cancer
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt
import seaborn as sns
breast_cancer = load_breast_cancer()
X = pd.DataFrame(breast_cancer.data, columns=breast_cancer.feature_names)
X = X[['mean area', 'mean compactness']]
y = pd.Categorical.from_codes(breast_cancer.target, breast_cancer.target_names)
print(y)
y = pd.get_dummies(y, drop_first=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25,random_state=1)
data=load_breast_cancer()
data1=pd.DataFrame(data.data,columns=data.feature_names)
print(data1.head())
print(data1.columns)
data1.columns=data.feature_names
NUM_POINTS=7
features_mean=list(data1.columns[1:NUM_POINTS+1])
feature_names=data.feature_names[1:NUM_POINTS+1]
color_dic={0:'red',1:'blue'}
target_list=list(data['target'])
print(target_list)
colors=list(map(lambda x:color_dic.get(x),target_list))
sns_fig=pd.plotting.scatter_matrix(data1[features_mean],c=colors,alpha=0.4,figsize=((10,10)))
plt.show()

"""sns.scatterplot(
    x='mean area',
    y='mean compactness',
    hue='benign',
    data=X_test.join(y_test, how='outer')
)
plt.show()
plt.scatter(
    X_test['mean area'],
    X_test['mean compactness'],
    c=y_pred,
    cmap='coolwarm',
    alpha=0.7
)
##plt.show()
"""
